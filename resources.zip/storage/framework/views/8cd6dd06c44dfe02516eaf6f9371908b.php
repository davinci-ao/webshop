<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="#" class="btn btn-success btn-sm mx-4 my-4">+ Add category</a>
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-12 mb-4">
                        <div class="card">
                            <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light" data-mdb-ripple-color="light">
                                <img class="card-img" src="<?php echo e(url('/images' . '/' . $category->file_path)); ?>"/>
                                <a href="#!">
                                    <div class="hover-overlay">
                                        <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                    </div>
                                </a>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title mb-3 text-reset"><?php echo e($category->name); ?></h5>
                                <div class="text-reset">
                                    <a href="<?php echo e(url('/category/showproductsbycategory/' . $category->id)); ?>" class="btn btn-dark btn-sm">see all <?php echo e($category->name); ?> products</a>
                                    <br>
                                    <hr>
                                    <br>
                                    <a href="<?php echo e(url('/category/showproductsbycategory/' . $category->id)); ?>" class="btn btn-success btn-sm">Edit <?php echo e($category->name); ?></a>
                                    <br>
                                    <hr>
                                    <br>
                                    <a href="<?php echo e(url('/category/showproductsbycategory/' . $category->id)); ?>" class="btn btn-danger btn-sm">Delete <?php echo e($category->name); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/admin/editcategory.blade.php ENDPATH**/ ?>