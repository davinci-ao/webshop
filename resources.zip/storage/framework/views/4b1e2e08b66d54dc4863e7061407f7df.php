<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">Update product</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('product/storeProduct/' .$product->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>"/>
        <label>Product name</label></br>
        <input type="text" name="name" id="name" value="<?php echo e($product->name); ?>" class="form-control"></br>

        <label>Product description</label></br>
        <input type="text" name="description" id="description" value="<?php echo e($product->description); ?>" class="form-control"></br>

        <label>Product price</label></br>
        <input type="text" name="price" id="price" value="<?php echo e($product->price); ?>" class="form-control"></br>

        <label>Product image link</label></br>
        <input type="text" name="file_path" id="file_path" value="<?php echo e($product->file_path); ?>" class="form-control"></br>

        <label>category of product</label></br>
        <select name="category_id" id="category_id" class="form-control">
          <option> -- Select One --</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select></br>

        <label>Product stock</label></br>
        <input type="text" name="stock" id="stock" value="<?php echo e($product->stock); ?>" class="form-control"></br>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/product/update.blade.php ENDPATH**/ ?>