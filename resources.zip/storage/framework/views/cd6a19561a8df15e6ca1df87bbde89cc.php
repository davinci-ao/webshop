    <?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Auth::check() && Auth::user()->admin == true): ?>
        <h1 class= mx-4>Welkom admin</h1>
        <a href="<?php echo e(url('/product')); ?>" class="btn btn-dark btn-xl mx-4 my-4">Edit products</a>
        <br>
        <a href="<?php echo e(url('/category')); ?>" class="btn btn-dark btn-xl mx-4 my-4">Edit categories</a>
        <br>
        <a href="<?php echo e(url('/admin/' . 'edituser/')); ?>" class="btn btn-dark btn-xl mx-4 my-4">Edit users</a>
        <br>      
<?php else: ?>

Welkom klant

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/welcome.blade.php ENDPATH**/ ?>