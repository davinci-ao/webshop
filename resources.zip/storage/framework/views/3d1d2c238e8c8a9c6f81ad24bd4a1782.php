<?php 

?>
    
    <?php $__env->startSection('content'); ?>
        <main class="page">
            <section class="shopping-cart dark">
                <div class="container">
                    <div class="block-heading">
                        <h2>Shopping Cart</h2>
                    </div>
                    <div class="content">
                        <div class="row">
                            <div class="col-md-12 col-lg-8">
                                <div class="items">
                                    <div class="product">
                                        <?php 
                                            $totalPrice = 0;
                                            
                                        ?>
                                        <div class="row">
                                            <?php if(session()->has('shoppingCart')): ?>
                                                <?php $__currentLoopData = session()->get('shoppingCart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-md-3">
                                                        <img class="img-fluid mx-auto d-block image" src="<?php echo e(url('/images' . '/' . $cartItem['product']['file_path'])); ?>">
                                                    </div>
                                                    <div class="col-md-8">
                                                        <div class="info">
                                                            <div class="row">
                                                                <div class="col-md-5 product-name">
                                                                    <div class="product-name">
                                                                        <a href="#"><?php echo e($cartItem['product']['name']); ?></a>
                                                                        <div class="product-info">
                                                                            <?php if($cartItem['product']['category']): ?>
                                                                                <div>category: <span class="value"><?php echo e($cartItem['product']['category']['name']); ?></span></div>
                                                                                <a href=<?php echo e("delete/" . $cartItem['product']['id']); ?> class="fa fa-trash"></a>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4 quantity">
                                                                    <label for="quantity">Quantity:</label>
                                                                    <button wire:click="decrementQuantity('<?php echo e($cartItem['product']['id']); ?>')">-</button>
                                                                    <span><?php echo e($cartItem['quantity']); ?></span>
                                                                    <button wire:click="incrementQuantity('<?php echo e($cartItem['product']['id']); ?>')">+</button>
                                                                </div>
                                                                <div class="col-md-3 subtotal">
                                                                    <label for="subtotal">subtotal:</label>
                                                                    <p>  <?php echo e($subTotal = $cartItem['subtotal'] * $cartItem['quantity']); ?> </p>
                                                                    <p class="hidetime" style="display: none"><?php echo e($totalPrice += $subTotal); ?></p>
                                                                   
                                                                </div>
                                                                <div class="col-md-3 price">
                                                                    <span>$<?php echo e($cartItem['product']['price']); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <p>Your cart is empty.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-lg-4">
                                <div class="summary">
                                    <div class="card">
                                        <h3>Summary</h3>
                                        <div class="summary-item"><span class="text">Total price: </span><span class="price">$<?php echo e($totalPrice); ?></span></div>
                                        <button type="button" class="btn btn-primary btn-lg btn-block">Checkout</button>
                                        <a href=<?php echo e("delete/"); ?> class="btn btn-danger btn-sm">Empty whole cart </a>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </section>
        </main>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/livewire/shopping-cart.blade.php ENDPATH**/ ?>