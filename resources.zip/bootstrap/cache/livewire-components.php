<?php return array (
  'shopping-cart' => 'App\\Http\\Livewire\\ShoppingCart',
);