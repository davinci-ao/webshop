<div>
<div>

<?php $__env->startSection('content'); ?>
	<main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container">
		        <div class="block-heading">
		          <h2>Shopping Cart</h2>
		        </div>
		        <div class="content">
	 				<div class="row">
	 					<div class="col-md-12 col-lg-8">
	 						<div class="items">
				 				<div class="product">
                                    <?php $totalPrice = 0;?>
				 					<div class="row">
                                        <?php if(Session::has('product')): ?>
                                        <?php $__currentLoopData = Session::get('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3">
                                                <img class="img-fluid mx-auto d-block image" src="<?php echo e(url('/images' . '/' . $item['file_path'])); ?>">
                                            </div>
                                            <div class="col-md-8">
                                                <div class="info">
                                                    <div class="row">
                                                        <div class="col-md-5 product-name">
                                                            <div class="product-name">
                                                                <a href="#"><?php echo e($item['name']); ?></a>
                                                                <div class="product-info">
                                                                    <?php if($item->category): ?>
                                                                        <div>category: <span class="value"><?php echo e($item->category->name); ?></span></div>
                                                                        <a href=<?php echo e("delete/" . $item['id']); ?> class="fa fa-trash"></a>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4 quantity">
                                                            <label for="quantity">Quantity:</label>
                                                            <button id="plus" type="button" wire:click.prevent="increaseQuantity("<?php echo e($item['id']); ?>")">+</button>
      	                                                    <button id="min" type="button" wire:click.prevent="decreaseQuantity("<?php echo e($item['id']); ?>")">-</button>
                                                            <input id="quantity" type="number" value ="1" class="form-control quantity-input">
                                                        </div>
                                                        <div class="col-md-3 price">
                                                            <span>$<?php echo e($item['price']); ?></span>
                                                            <p class="hidetime" style="display: none"><?php echo e($totalPrice += (int)($item['price'])); ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
					 				</div>
				 				</div>
				 			</div>
			 			</div>
			 			<div class="col-md-12 col-lg-4">
			 				<div class="summary">
                                <div class="card">
                                    <h3>Summary</h3>
                                    <div class="summary-item"><span class="text">Total price: </span><span class="price">$<?php echo e($totalPrice); ?></span></div>
                                    <button type="button" class="btn btn-primary btn-lg btn-block">Checkout</button>
                                    <a href=<?php echo e("delete/"); ?> class="btn btn-danger btn-sm">Empty whole cart </a>
                                </div>
				 			</div>
			 			</div>
		 			</div> 
		 		</div>
	 		</div>
		</section>
	</main>
</body>

<?php $__env->stopSection(); ?>


</div>

</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/livewire/index.blade.php ENDPATH**/ ?>