<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="button-box">
            <button class="btn btn-dark btn-sm dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                Sort products
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <li><a class="dropdown-item" href="<?php echo e(url('/product')); ?>" class="btn btn-dark btn-sm">Default</a></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnPriceHigh')); ?>" class="btn btn-dark btn-sm">Price (high)</a></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnPriceLow')); ?>" class="btn btn-dark btn-sm">Price (low)</a></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnNameHigh')); ?>" class="btn btn-dark btn-sm">Name (A-Z)</a></li>
                <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnNameLow')); ?>" class="btn btn-dark btn-sm">Name (Z-A)</a></li>
            </ul>
            <button class="btn btn-dark btn-sm dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                Sort by category
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li value="<?php echo e($category->id); ?>"><a class="dropdown-item" href="<?php echo e(url('/product/sortByCategory/' . $category->id)); ?>" class="btn btn-dark btn-sm"><?php echo e($category->name); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </ul>
            <?php if(Auth::check() && Auth::user()->admin == "1"): ?>
            <a href="<?php echo e(url('/product/create')); ?>" class="btn btn-success btn-sm">+ Add product</a>
        <?php endif; ?>
        </div>
        <br>
        <div class="row">
        <div class="grid-container">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light" data-mdb-ripple-color="light">
                            <img class="img" src="<?php echo e(url('/images' . '/' . $product->file_path)); ?>"/>
                            <a href="#!">
                                <div class="hover-overlay">
                                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                </div>
                            </a>
                        </div>
                        <div class="card-body">
                        <h5 class="card-title mb-3 text-reset"><?php echo e($product->name); ?></h5>
                            <div class="text-reset">
                                <?php if($product->category): ?>
                                    <p><?php echo e($product->category->name); ?></p>
                                <?php endif; ?>
                            </div>
                            <h6 class="mb-3">$<?php echo e($product->price); ?></h6>
                            <?php if($product->stock < 1): ?>
                                <h6 class="mb-3 text-danger">Out of stock</h6>
                            <?php elseif($product->stock < 4): ?>
                                <h6 class="mb-3 text-warning">Only a few left in stock</h6>
                            <?php else: ?>
                                <h6 class="mb-3 text-success">In stock</h6>
                            <?php endif; ?>
                            <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>"/>
                            <?php if(Auth::check() && Auth::user()->admin == "1"): ?>
                                <div class="button-box">
                            <?php endif; ?>  
                            <a href="<?php echo e(url('/product/' . 'details/' . $product->id . "/" . $product->category_id)); ?>" class="btn btn-dark btn-sm">See product</a>
                            <?php if(Auth::check() && Auth::user()->admin == "1"): ?>
                                <a href="<?php echo e(url('/product/edit/' . $product->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                <a href="<?php echo e(url('/product/delete/' . $product->id)); ?>" class="btn btn-danger btn-sm">Delete</a>
                                </div>
                                <hr>                     
                                <form action="<?php echo e(url('product/storeStockOfProduct/' .$product->id)); ?>" method="post">
                                <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>"/>
                                <form action="<?php echo e(url('cart/index/' . $product->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>"/>
                                    <label>Stock:</label></br>
                                    <input type="text" name="stock" id="stock" value="<?php echo e($product->stock); ?>" class="form-control"><br>
                                    <input type="submit" value="Update stock" class="btn btn-success btn-sm"><br>
                                </form>
                                <hr>
                            <?php endif; ?>  
                            <?php if(Auth::check()): ?>
                            <form action="<?php echo e(url('cart/index/' . $product->id)); ?>" method="post">
                            <?php else: ?>
                            <form action="<?php echo e(url('register')); ?>">
                            <?php endif; ?>
                                <?php echo csrf_field(); ?>

                                <br>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <input type="number" name="quantity" value="1" min="1"><br>
                                <br>
                                <button type="submit" class="btn btn-dark">Add to cart </button><br>
                            </form>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>   
        </div>
    </div>       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/category/showproductsbycategory.blade.php ENDPATH**/ ?>