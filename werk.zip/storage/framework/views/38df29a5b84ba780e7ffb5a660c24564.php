<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-header">Add Product</div>
  <div class="card-body">
      
      <form action="<?php echo e(url('product')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>Name of product</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>

        <label>description of product</label></br>
        <input type="text" name="description" id="description" class="form-control"></br>

        <label>price of product</label></br>
        <input type="text" name="price" id="price" class="form-control"></br>

        <label>file_path of product</label></br>
        <input type="text" name="file_path" id="file_path" class="form-control"></br>

        <label>category of product</label></br>
        <select name="category_id" id="category_id" class="form-control">
          <option> -- Select One --</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      </select></br>

        <label>stocks of product</label></br>
        <input type="text" name="stock" id="stock" class="form-control"></br>
        
        
    
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
  
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/product/create.blade.php ENDPATH**/ ?>