    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="dropdown">
                <button class="btn btn-dark btn-sm dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                  Sort products
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                    <li><a class="dropdown-item" href="<?php echo e(url('/product')); ?>" class="btn btn-dark btn-sm">Default</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnPriceHigh')); ?>" class="btn btn-dark btn-sm">Price (high)</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnPriceLow')); ?>" class="btn btn-dark btn-sm">Price (low)</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnNameHigh')); ?>" class="btn btn-dark btn-sm">Name (A-Z)</a></li>
                  <li><a class="dropdown-item" href="<?php echo e(url('/product/sortOnNameLow')); ?>" class="btn btn-dark btn-sm">Name (Z-A)</a></li>
                </ul>
              </div>
            <div class="row">
                <a href="<?php echo e(url('/product/create')); ?>" class="btn btn-success btn-sm mx-4 my-4">+ Add product</a>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-12 mb-4">
                            <div class="card">
                                <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light" data-mdb-ripple-color="light">
                                    <img class="card-img" src="<?php echo e(url('/images' . '/' . $product->file_path)); ?>"/>
                                    <a href="#!">
                                        <div class="hover-overlay">
                                            <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                                        </div>
                                    </a>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title mb-3 text-reset"><?php echo e($product->name); ?></h5>
                                        <div class="text-reset">
                                            <?php if($product->category): ?>
                                                <p><?php echo e($product->category->name); ?></p>
                                            <?php endif; ?>
                                            </div>
                                            <form action="<?php echo e(url('product/storeStockOfProduct/' .$product->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>

                                                <input type="hidden" name="id" id="id" value="<?php echo e($product->id); ?>"/>
                                                <label>Stock of <?php echo e($product->name); ?></label></br>
                                                <input type="text" name="stock" id="stock" value="<?php echo e($product->stock); ?>" class="form-control"><br>
                                                <input type="submit" value="Update stock of <?php echo e($product->name); ?>" class="btn btn-success btn-sm"><br>
                                                <hr>
                                            </form><br>
                                            <h6 class="mb-3">$<?php echo e($product->price); ?></h6>
                                            <a href="<?php echo e(url('/product/' . 'details/' . $product->id)); ?>" class="btn btn-dark btn-sm">See <?php echo e($product->name); ?></a>
                                            <br>
                                            <hr>
                                            <br>
                                            <a href="<?php echo e(url('/product/edit/' . $product->id)); ?>" class="btn btn-success btn-sm">edit <?php echo e($product->name); ?></a>
                                            <br>
                                            <hr>
                                            <br>
                                            <a href="<?php echo e(url('/product/delete/' . $product->id)); ?>" class="btn btn-danger btn-sm">Delete <?php echo e($product->name); ?></a>
                                        </div>
                                    </div>
                                </div>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/admin/editproduct.blade.php ENDPATH**/ ?>