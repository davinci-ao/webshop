<?php $__env->startSection('content'); ?>
    <div class="container py-5">
      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-4">
          <div class="card text-black">
            <img class="card-img"  src="<?php echo e(url('/images' . '/' . $product->file_path)); ?>"/>
            <div class="card-body">
              <div class="text-center">
                <p class="text-muted mb-4"><?php echo e($product->name); ?></p>
              </div>
              <div class="text-center">
                <p class="text-muted mb-4"><?php echo e($product->description); ?></p>
              </div>
              <div>
                <hr>
                <div class="d-flex justify-content-between">
                  <span>Price</span><span>$<?php echo e($product->price); ?></span>
                </div>
                <div class="text-center">
                  
                  <?php if($product->stock < 1): ?>
                  <h6 class="mb-3 text-danger">out of stock</h6>
              <?php elseif($product->stock < 4): ?>
                  <h6 class="mb-3 text-warning">Only a few left in stock</h6>
              <?php else: ?>
                  <h6 class="mb-3 text-success">in stock</h6>
              <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <hr>
    <div class="container">
      <h1 class="text-center">related for you</h3>
    </div>
    <hr>
    <div class="container">
      <div class="row">
          <?php $__currentLoopData = $categoryPoducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryPoduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-2 col-md-12 mb-4">
                  <div class="card">
                      <div class="bg-image hover-zoom ripple ripple-surface ripple-surface-light" data-mdb-ripple-color="light">
                          <img class="card-img" src="<?php echo e(url('/images' . '/' . $categoryPoduct->file_path)); ?>"/>
                          <a href="#!">
                              <div class="hover-overlay">
                                  <div class="mask" style="background-color: rgba(251, 251, 251, 0.15);"></div>
                              </div>
                          </a>
                      </div>
                      <div class="card-body">
                          <h5 class="card-title mb-3 text-reset"><?php echo e($categoryPoduct->name); ?></h5>
                          <div class="text-reset">
                              <?php if($categoryPoduct->category): ?>
                              <p><?php echo e($categoryPoduct->category->name); ?></p>
                              <?php endif; ?>
                          </div>
                          <h6 class="mb-3">$<?php echo e($categoryPoduct->price); ?></h6>
                          <?php if($categoryPoduct->stock < 1): ?>
                              <h6 class="mb-3 text-danger">Out of stock</h6>
                          <?php elseif($categoryPoduct->stock < 4): ?>
                              <h6 class="mb-3 text-warning">Only a few left in stock</h6>
                          <?php else: ?>
                              <h6 class="mb-3 text-success">In stock</h6>
                          <?php endif; ?>
                          <input type="hidden" name="id" id="id" value="<?php echo e($categoryPoduct->id); ?>"/>
                          <a href="<?php echo e(url('/product/' . 'details/' . $categoryPoduct->id . "/" . $categoryPoduct->category_id)); ?>" class="btn btn-dark btn-sm">See <?php echo e($product->name); ?></a>
                      </div>
                  </div>
              </div>      
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
  </div>       
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/product/details.blade.php ENDPATH**/ ?>