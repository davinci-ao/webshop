    <?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-12 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h2 class="card-title mb-3 text-reset"><?php echo e($user->username); ?></h2>
                                        <div class="text-reset">
                                            </div>
                                            <a href="<?php echo e(url('/user/' . 'details/' . $user->id)); ?>" class="btn btn-dark btn-sm">See <?php echo e($user->username); ?></a>
                                            <br>
                                            <hr>
                                            <br>
                                            <a href="<?php echo e(url('/user/' . 'details/' . $user->id)); ?>" class="btn btn-success btn-sm">Edit <?php echo e($user->username); ?></a>
                                            <br>
                                            <hr>
                                            <br>
                                            <a href="<?php echo e(url('/user/' . 'details/' . $user->id)); ?>" class="btn btn-danger btn-sm">Delete <?php echo e($user->username); ?></a>
                                        </div>
                                    </div>
                                </div>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webshop\resources\views/admin/edituser.blade.php ENDPATH**/ ?>